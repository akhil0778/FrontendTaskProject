let menuBar = document.getElementById('menuBar');
let crossIcon = document.getElementById('cross-icon');
let navbarMenu = document.getElementById('navbarMenu');


const togglenavBar = () => {
    navbarMenu.classList.toggle('active')

}
menuBar.addEventListener('click', () => togglenavBar());